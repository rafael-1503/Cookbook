import { useEffect, useState } from "react";
import axios from "../axiosURL";

const useCategories = () => {
    const [categories, setCategories] = useState([])

    useEffect(() => {
        const fetchCategories = async () => {
            try{
                const res = await axios.get("cookbook/categories")
                setCategories(res.data)
            } catch(err){
                console.error("Fehler beim Laden: ", err)
            }
        }
        fetchCategories()
    }, [])

    return{categories}
}

export default useCategories;