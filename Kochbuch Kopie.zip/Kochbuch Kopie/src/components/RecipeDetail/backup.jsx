



    return(
        <div className="RecipeDetail">
            <div className="RecipeDetail__Header">
                <img src={recipe.href} alt={recipe.name}/>
                <h1>{recipe.name}</h1>
            </div>
            <div className="RecipeDetail__Content">
                <div className="RecipeDetail__Content__Title">
                    <h3>Zutaten für</h3>
                    <input name="p" type="Number" placeholder={recipe.portion} onChange={(e)=> {
                        const value = e.target.value;
                        setInputPortion(value);
                        calculatePortion(value);
                    }}/>
                    <h3>Portionen</h3>
                </div>
                <div className="RecipeDetail__Content__Wrapper">
                    {recipe.ingredients.map((ingredient, index) => (
                        <div className="RecipeDetail__Content__Ingredients__Row" key={index}>
                            
                                <span className="RecipeDetail__Content__Ingredients__Row__Amount">{inputPortion ? portionAmount[index]?.amount : ingredient.amount} {ingredient.unit}</span>
                                <span className="RecipeDetail__Content__Ingredients__Row__Ingredient">{ingredient.ingredient}</span>
                            
                        </div>
                    ))}
                </div>
                <div className="HorizontalDivider"></div>
                <div className="RecipeDetail__Content__Title">
                    <h3>Zubereitung</h3>
                </div>
                <div className="RecipeDetail__Content__Wrapper">
                    
                    <p className="RecipeDetail__Content__Directions__Time"><Clock4 size={16} className="RecipeDetail__Content__Directions__Clock"/> {recipe.time} Min.</p> 
                    <p className="RecipeDetail__Content__Directions__Content">{recipe.directions}</p>
                </div>
                <div className="RecipeDetail__Content__Wrapper">
                    {categories.map((category, index) => (
                        <div className="RecipeDetail__Content__Categories__All">
                            <p>{category.name}</p>
                        </div>
                    ))}
                </div>
                <div className="HorizontalDivider"></div>
                <div className="RecipeDetail__Content__Title">
                    <h3>Kommentare</h3>
                </div>
                <div className="RecipeDetail__Content__Wrapper">
                    <div className="RecipeDetail__Content__Comments__AddComment">
                        <input name="newComment" type="Text" placeholder="Kommentar schreiben... " onChange={onNewCommentChange}/>
                        <button onClick={onSaveComment}><Pencil size={20} fill="grey" strokeWidth={2.5}/></button>
                    </div>
                    {recipe.comments.map((comment, index) => (
                        <div className="RecipeDetail__Content__Comments__Comment">
                            <p className="RecipeDetail__Content__Comments__User"><CircleUserRound />{comment.user?.firstname} {comment.user?.lastname}</p>
                            <p className="RecipeDetail__Content__Comments__Text" >{comment.comment}</p>
                            <div className="HorizontalDivider__Comment"></div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    )
